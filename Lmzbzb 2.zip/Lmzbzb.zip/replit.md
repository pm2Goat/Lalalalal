# Discord Bot Control Panel

## Overview

This is a full-stack Discord bot management application built with a modern React frontend and Express.js backend. The application provides a web-based control panel for managing Discord bots, allowing users to configure bot settings, monitor activity, and control bot operations through an intuitive dashboard interface.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **UI Framework**: shadcn/ui components built on Radix UI primitives
- **Styling**: Tailwind CSS with custom dark theme
- **State Management**: TanStack Query (React Query) for server state
- **Routing**: Wouter for client-side routing
- **Form Handling**: React Hook Form with Zod validation
- **Real-time Updates**: WebSocket connection for live data

### Backend Architecture
- **Runtime**: Node.js with Express.js
- **Language**: TypeScript with ES modules
- **Database**: PostgreSQL with Drizzle ORM
- **Authentication**: Session-based with bcrypt password hashing
- **Real-time Communication**: WebSocket server for live updates
- **Bot Integration**: Discord.js for bot functionality

## Key Components

### Database Schema
- **users**: User authentication and management
- **bot_configs**: Bot configuration settings (token, channel, messages, delays)
- **bot_stats**: Runtime statistics (messages sent, uptime, last activity)
- **activity_logs**: System activity and error logging

### Authentication System
- Simple password-based authentication
- Session management with secure cookies
- Admin-only access with configurable password
- Protected API routes with middleware

### Bot Management Service
- Discord bot lifecycle management (start/stop)
- Real-time message sending with configurable delays
- Statistics tracking and reporting
- Error handling and logging

### Real-time Features
- WebSocket connection for live updates
- Real-time statistics (uptime, message count)
- Live activity logging
- Instant status updates

## Data Flow

1. **Authentication Flow**:
   - User submits password → Backend validates → Session created → Frontend updates auth state

2. **Bot Configuration Flow**:
   - User configures bot settings → Form validation → API request → Database update → Bot service restart

3. **Real-time Updates Flow**:
   - Bot service events → WebSocket broadcast → Frontend state update → UI refresh

4. **Statistics Flow**:
   - Bot operations → Statistics update → Database write → WebSocket broadcast → Dashboard update

## External Dependencies

### Core Dependencies
- **@neondatabase/serverless**: PostgreSQL database connection
- **discord.js**: Discord API integration
- **drizzle-orm**: Type-safe database operations
- **bcrypt**: Password hashing
- **ws**: WebSocket server implementation

### UI Dependencies
- **@radix-ui/***: Accessible UI primitives
- **@tanstack/react-query**: Server state management
- **react-hook-form**: Form handling
- **zod**: Schema validation
- **tailwindcss**: Utility-first styling

### Development Dependencies
- **vite**: Build tool and dev server
- **typescript**: Type checking
- **tsx**: TypeScript execution
- **esbuild**: Production bundling

## Deployment Strategy

### Development Mode
- Vite dev server for frontend with HMR
- tsx for TypeScript execution
- Concurrent frontend and backend development
- WebSocket development support

### Production Build
- Vite builds React app to static files
- esbuild bundles backend with external dependencies
- Static file serving from Express
- Environment-based configuration

### Replit Configuration
- Configured for Node.js 20 runtime
- PostgreSQL 16 database module
- Autoscale deployment target
- Custom run commands for development and production

## Changelog

```
Changelog:
- June 16, 2025. Initial setup
- June 16, 2025. Created bothosting-upload folder with CommonJS version for deployment
- June 16, 2025. Fixed import/export issues for bothosting.com compatibility
```

## User Preferences

```
Preferred communication style: Simple, everyday language.
```