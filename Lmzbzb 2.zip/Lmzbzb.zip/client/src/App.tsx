import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { useEffect, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import LoginPage from "@/pages/login";
import DashboardPage from "@/pages/dashboard";
import { WebSocketProvider } from "@/lib/websocket";

function AuthChecker() {
  const [isChecking, setIsChecking] = useState(true);
  
  const { data: authStatus } = useQuery<{ authenticated: boolean }>({
    queryKey: ['/api/auth/status'],
    enabled: isChecking,
    retry: false,
  });

  useEffect(() => {
    if (authStatus !== undefined) {
      setIsChecking(false);
    }
  }, [authStatus]);

  if (isChecking) {
    return (
      <div className="min-h-screen bg-slate-900 flex items-center justify-center">
        <div className="text-center">
          <div className="h-16 w-16 mx-auto mb-4 bg-gradient-to-r from-primary to-primary/80 rounded-full flex items-center justify-center">
            <div className="animate-spin h-8 w-8 border-2 border-white border-t-transparent rounded-full"></div>
          </div>
          <p className="text-slate-400">جاري التحميل...</p>
        </div>
      </div>
    );
  }

  return (
    <Switch>
      <Route path="/" component={() => (authStatus && authStatus.authenticated) ? <DashboardPage /> : <LoginPage />} />
      <Route component={() => <div className="min-h-screen bg-slate-900 flex items-center justify-center text-slate-50">404 - الصفحة غير موجودة</div>} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WebSocketProvider>
          <div className="rtl">
            <Toaster />
            <AuthChecker />
          </div>
        </WebSocketProvider>
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
