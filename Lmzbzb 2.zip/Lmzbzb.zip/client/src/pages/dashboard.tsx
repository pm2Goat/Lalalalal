import { useMutation, useQuery } from "@tanstack/react-query";
import { Bot, LogOut, Settings, BarChart3, MessageSquare, Clock } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { authApi } from "@/lib/auth";
import { queryClient } from "@/lib/queryClient";
import { useWebSocket } from "@/lib/websocket";
import BotConfigForm from "@/components/bot-config-form";
import BotStatistics from "@/components/bot-statistics";
import ActivityLog from "@/components/activity-log";
import QuickMessageForm from "@/components/quick-message-form";

export default function DashboardPage() {
  const { toast } = useToast();
  const { isConnected } = useWebSocket();

  const { data: botStatus } = useQuery({
    queryKey: ['/api/bot/status'],
    refetchInterval: 5000,
  });

  const logoutMutation = useMutation({
    mutationFn: authApi.logout,
    onSuccess: () => {
      toast({
        title: "✅ تم تسجيل الخروج بنجاح",
        description: "إلى اللقاء!",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/auth/status'] });
    },
  });

  const formatUptime = (seconds: number) => {
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const secs = seconds % 60;
    return `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <div className="min-h-screen bg-slate-900">
      {/* Header */}
      <header className="bg-slate-800 border-b border-slate-700 px-4 py-4">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center space-x-4 space-x-reverse">
            <div className="h-10 w-10 bot-icon-gradient rounded-lg flex items-center justify-center">
              <Bot className="h-6 w-6 text-white" />
            </div>
            <div>
              <h1 className="text-xl font-bold text-slate-50">لوحة تحكم البوت</h1>
              <p className="text-sm text-slate-400">Discord Bot Management</p>
            </div>
          </div>
          
          <div className="flex items-center space-x-4 space-x-reverse">
            {/* WebSocket Status */}
            <div className="flex items-center space-x-2 space-x-reverse px-3 py-1.5 rounded-full bg-slate-700">
              <div className={`h-2 w-2 rounded-full ${isConnected ? 'bg-green-500' : 'bg-red-500 animate-pulse'}`}></div>
              <span className="text-sm text-slate-300">
                {isConnected ? 'متصل' : 'منقطع'}
              </span>
            </div>

            {/* Bot Status */}
            <div className="flex items-center space-x-2 space-x-reverse px-3 py-1.5 rounded-full bg-slate-700">
              <div className={`h-2 w-2 rounded-full ${
                botStatus?.isRunning ? 'bg-green-500' : 'bg-red-500 animate-pulse'
              }`}></div>
              <span className="text-sm text-slate-300">
                {botStatus?.status || 'غير معروف'}
              </span>
            </div>
            
            <Button
              variant="ghost"
              size="sm"
              className="text-slate-400 hover:text-slate-300"
              onClick={() => logoutMutation.mutate()}
              disabled={logoutMutation.isPending}
            >
              <LogOut className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto p-4 space-y-6">
        {/* Bot Configuration */}
        <Card className="card-dark">
          <CardHeader>
            <CardTitle className="text-xl text-slate-50 flex items-center gap-2">
              <Settings className="h-5 w-5 text-primary" />
              إعدادات البوت
            </CardTitle>
          </CardHeader>
          <CardContent>
            <BotConfigForm />
          </CardContent>
        </Card>

        {/* Statistics */}
        <BotStatistics />

        {/* Activity Log */}
        <Card className="card-dark">
          <CardHeader>
            <CardTitle className="text-lg text-slate-50 flex items-center gap-2">
              <BarChart3 className="h-5 w-5 text-primary" />
              سجل الأنشطة
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ActivityLog />
          </CardContent>
        </Card>

        {/* Quick Message Update */}
        <Card className="card-dark">
          <CardHeader>
            <CardTitle className="text-lg text-slate-50 flex items-center gap-2">
              <MessageSquare className="h-5 w-5 text-primary" />
              تحديث سريع للرسالة
            </CardTitle>
          </CardHeader>
          <CardContent>
            <QuickMessageForm />
          </CardContent>
        </Card>
      </main>
    </div>
  );
}
