import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation } from "@tanstack/react-query";
import { Send } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Form, FormControl, FormField, FormItem } from "@/components/ui/form";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { quickMessageSchema, type QuickMessageRequest } from "@shared/schema";

export default function QuickMessageForm() {
  const { toast } = useToast();

  const form = useForm<QuickMessageRequest>({
    resolver: zodResolver(quickMessageSchema),
    defaultValues: {
      message: "",
    },
  });

  const updateMessageMutation = useMutation({
    mutationFn: async (data: QuickMessageRequest) => {
      const response = await apiRequest('POST', '/api/bot/quick-message', data);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "✏️ تم تحديث الرسالة",
        description: "تم تحديث الرسالة بنجاح",
      });
      form.reset();
    },
    onError: (error: any) => {
      toast({
        title: "❌ فشل في تحديث الرسالة",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: QuickMessageRequest) => {
    updateMessageMutation.mutate(data);
  };

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="flex gap-4">
        <FormField
          control={form.control}
          name="message"
          render={({ field }) => (
            <FormItem className="flex-1">
              <FormControl>
                <Input
                  placeholder="رسالة جديدة للتحديث السريع..."
                  className="input-dark"
                  {...field}
                />
              </FormControl>
            </FormItem>
          )}
        />
        
        <Button
          type="submit"
          className="btn-gradient btn-enhanced"
          disabled={updateMessageMutation.isPending}
        >
          {updateMessageMutation.isPending ? (
            <>
              <div className="animate-spin h-4 w-4 border-2 border-white border-t-transparent rounded-full ml-1"></div>
              جاري التحديث...
            </>
          ) : (
            <>
              <Send className="h-4 w-4 ml-1" />
              تحديث
            </>
          )}
        </Button>
      </form>
    </Form>
  );
}
