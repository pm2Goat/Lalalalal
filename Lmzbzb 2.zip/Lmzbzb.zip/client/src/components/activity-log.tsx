import { useMutation, useQuery } from "@tanstack/react-query";
import { Trash2, Inbox } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import type { ActivityLog } from "@shared/schema";

export default function ActivityLog() {
  const { toast } = useToast();

  const { data: logs = [] } = useQuery<ActivityLog[]>({
    queryKey: ['/api/logs'],
    refetchInterval: 5000,
  });

  const clearLogsMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest('DELETE', '/api/logs');
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "🗑️ تم مسح السجل",
        description: "تم مسح جميع السجلات بنجاح",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/logs'] });
    },
    onError: (error: any) => {
      toast({
        title: "❌ فشل في مسح السجل",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const getActivityColor = (type: string) => {
    switch (type) {
      case 'success':
        return 'activity-success';
      case 'warning':
        return 'activity-warning';
      case 'error':
        return 'activity-error';
      case 'info':
      default:
        return 'activity-info';
    }
  };

  const formatTimeAgo = (timestamp: string) => {
    const now = new Date();
    const time = new Date(timestamp);
    const diffInSeconds = Math.floor((now.getTime() - time.getTime()) / 1000);
    
    if (diffInSeconds < 60) {
      return 'الآن';
    } else if (diffInSeconds < 3600) {
      const minutes = Math.floor(diffInSeconds / 60);
      return `منذ ${minutes} دقيقة`;
    } else if (diffInSeconds < 86400) {
      const hours = Math.floor(diffInSeconds / 3600);
      return `منذ ${hours} ساعة`;
    } else {
      const days = Math.floor(diffInSeconds / 86400);
      return `منذ ${days} يوم`;
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <p className="text-sm text-slate-400">آخر {logs.length} نشاط</p>
        <Button
          variant="ghost"
          size="sm"
          className="text-slate-400 hover:text-slate-300"
          onClick={() => clearLogsMutation.mutate()}
          disabled={clearLogsMutation.isPending || logs.length === 0}
        >
         {clearLogsMutation.isPending ? (
            <div className="animate-spin h-4 w-4 border-2 border-slate-400 border-t-transparent rounded-full ml-1"></div>
          ) : (
            <Trash2 className="h-4 w-4 ml-1" />
          )}
          مسح السجل
        </Button>
      </div>

      <div className="space-y-2 max-h-64 overflow-y-auto activity-log">
        {logs.length === 0 ? (
          <div className="text-center py-8 text-slate-400">
            <Inbox className="h-12 w-12 mx-auto mb-2 opacity-50" />
            <p>لا توجد أنشطة بعد</p>
          </div>
        ) : (
          logs.map((log) => (
            <div
              key={log.id}
              className="flex items-start space-x-3 space-x-reverse p-3 bg-slate-700/50 rounded-lg"
            >
              <div className={`activity-dot ${getActivityColor(log.type)}`}></div>
              <div className="flex-1 min-w-0">
                <p className="text-sm text-slate-300">{log.message}</p>
                <p className="text-xs text-slate-400">
                  {formatTimeAgo(log.timestamp.toString())}
                </p>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}
