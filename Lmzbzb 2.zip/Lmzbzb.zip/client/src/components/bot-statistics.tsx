import { useQuery } from "@tanstack/react-query";
import { Send, Clock, MessageSquare } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";

export default function BotStatistics() {
  const { data: stats } = useQuery({
    queryKey: ['/api/bot/stats'],
    refetchInterval: 1000,
  });

  const formatUptime = (seconds: number) => {
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const secs = seconds % 60;
    return `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const formatLastMessage = (message: string | null) => {
    if (!message) return "لم يتم الإرسال بعد";
    return message.length > 30 ? message.substring(0, 30) + "..." : message;
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
      {/* Messages Sent */}
      <Card className="card-dark">
        <CardContent className="p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-slate-400">الرسائل المرسلة</p>
              <p className="text-2xl font-bold text-green-500">
                {stats?.messagesSent || 0}
              </p>
            </div>
            <div className="h-12 w-12 bg-green-500/20 rounded-lg flex items-center justify-center">
              <Send className="h-6 w-6 text-green-500" />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Uptime */}
      <Card className="card-dark">
        <CardContent className="p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-slate-400">وقت التشغيل</p>
              <p className="text-2xl font-bold text-primary">
                {formatUptime(stats?.uptime || 0)}
              </p>
            </div>
            <div className="h-12 w-12 bg-primary/20 rounded-lg flex items-center justify-center">
              <Clock className="h-6 w-6 text-primary" />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Last Message */}
      <Card className="card-dark">
        <CardContent className="p-6">
          <div className="flex items-center justify-between">
            <div className="flex-1 min-w-0">
              <p className="text-sm text-slate-400">آخر رسالة</p>
              <p className="text-sm text-slate-300 truncate">
                {formatLastMessage(stats?.lastMessage)}
              </p>
            </div>
            <div className="h-12 w-12 bg-yellow-500/20 rounded-lg flex items-center justify-center flex-shrink-0">
              <MessageSquare className="h-6 w-6 text-yellow-500" />
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
