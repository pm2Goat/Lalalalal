import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation, useQuery } from "@tanstack/react-query";
import { Eye, EyeOff, Key, Hash, Clock, MessageSquare, Play, Square } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { insertBotConfigSchema, type InsertBotConfig } from "@shared/schema";

export default function BotConfigForm() {
  const [showToken, setShowToken] = useState(false);
  const { toast } = useToast();

  const form = useForm<InsertBotConfig>({
    resolver: zodResolver(insertBotConfigSchema),
    defaultValues: {
      botToken: "",
      channelId: "",
      messageContent: "",
      messageDelay: 5,
      isActive: false,
    },
  });

  const { data: config } = useQuery({
    queryKey: ['/api/bot/config'],
    onSuccess: (data) => {
      if (data) {
        form.reset(data);
      }
    },
  });

  const { data: botStatus } = useQuery({
    queryKey: ['/api/bot/status'],
  });

  const startBotMutation = useMutation({
    mutationFn: async (data: InsertBotConfig) => {
      const response = await apiRequest('POST', '/api/bot/start', data);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "✅ تم تشغيل البوت بنجاح",
        description: "البوت يعمل الآن ويرسل الرسائل",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/bot/status'] });
      queryClient.invalidateQueries({ queryKey: ['/api/bot/config'] });
    },
    onError: (error: any) => {
      toast({
        title: "❌ فشل في تشغيل البوت",
        description: error.message || "تحقق من التوكن ومعرف القناة",
        variant: "destructive",
      });
    },
  });

  const stopBotMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest('POST', '/api/bot/stop');
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "⛔ تم إيقاف البوت",
        description: "البوت متوقف الآن",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/bot/status'] });
    },
    onError: (error: any) => {
      toast({
        title: "❌ فشل في إيقاف البوت",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: InsertBotConfig) => {
    startBotMutation.mutate(data);
  };

  const messageContent = form.watch("messageContent");
  const characterCount = messageContent?.length || 0;

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Bot Token */}
          <div className="lg:col-span-2">
            <FormField
              control={form.control}
              name="botToken"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="text-slate-300 flex items-center gap-2">
                    <Key className="h-4 w-4 text-primary" />
                    توكن البوت (Bot Token)
                  </FormLabel>
                  <FormControl>
                    <div className="relative">
                      <Input
                        type={showToken ? "text" : "password"}
                        placeholder="Bot Token من Discord Developer Portal"
                        className="input-dark pr-12"
                        {...field}
                      />
                      <Button
                        type="button"
                        variant="ghost"
                        size="sm"
                        className="absolute left-2 top-1/2 -translate-y-1/2 h-8 w-8 p-0 text-slate-400 hover:text-slate-300"
                        onClick={() => setShowToken(!showToken)}
                      >
                        {showToken ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                      </Button>
                    </div>
                  </FormControl>
                  <p className="text-xs text-slate-400 flex items-center gap-1">
                    <span>احصل على التوكن من Discord Developer Portal</span>
                  </p>
                  <FormMessage />
                </FormItem>
              )}
            />
          </div>

          {/* Channel ID */}
          <FormField
            control={form.control}
            name="channelId"
            render={({ field }) => (
              <FormItem>
                <FormLabel className="text-slate-300 flex items-center gap-2">
                  <Hash className="h-4 w-4 text-primary" />
                  معرف القناة (Channel ID)
                </FormLabel>
                <FormControl>
                  <Input
                    type="text"
                    placeholder="1234567890123456789"
                    className="input-dark"
                    {...field}
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          {/* Message Delay */}
          <FormField
            control={form.control}
            name="messageDelay"
            render={({ field }) => (
              <FormItem>
                <FormLabel className="text-slate-300 flex items-center gap-2">
                  <Clock className="h-4 w-4 text-primary" />
                  التأخير (بالثواني)
                </FormLabel>
                <FormControl>
                  <Input
                    type="number"
                    min="1"
                    max="3600"
                    className="input-dark"
                    {...field}
                    onChange={(e) => field.onChange(parseInt(e.target.value))}
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          {/* Message Content */}
          <div className="lg:col-span-2">
            <FormField
              control={form.control}
              name="messageContent"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="text-slate-300 flex items-center gap-2">
                    <MessageSquare className="h-4 w-4 text-primary" />
                    محتوى الرسالة
                  </FormLabel>
                  <FormControl>
                    <Textarea
                      placeholder="اكتب الرسالة التي تريد إرسالها..."
                      className="input-dark resize-none"
                      rows={4}
                      {...field}
                    />
                  </FormControl>
                  <div className="flex justify-between items-center">
                    <p className="text-xs text-slate-400">
                      يمكنك استخدام Markdown و Emojis
                    </p>
                    <span className="text-xs text-slate-400">
                      {characterCount}/2000
                    </span>
                  </div>
                  <FormMessage />
                </FormItem>
              )}
            />
          </div>

          {/* Control Buttons */}
          <div className="lg:col-span-2 flex gap-4">
            <Button
              type="submit"
              className="flex-1 btn-success btn-enhanced"
              disabled={startBotMutation.isPending || botStatus?.isRunning}
            >
              {startBotMutation.isPending ? (
                <>
                  <div className="animate-spin h-4 w-4 border-2 border-white border-t-transparent rounded-full ml-2"></div>
                  جاري التشغيل...
                </>
              ) : (
                <>
                  <Play className="h-4 w-4 ml-2" />
                  تشغيل البوت
                </>
              )}
            </Button>

            <Button
              type="button"
              className="flex-1 btn-danger btn-enhanced"
              disabled={stopBotMutation.isPending || !botStatus?.isRunning}
              onClick={() => stopBotMutation.mutate()}
            >
              {stopBotMutation.isPending ? (
                <>
                  <div className="animate-spin h-4 w-4 border-2 border-white border-t-transparent rounded-full ml-2"></div>
                  جاري الإيقاف...
                </>
              ) : (
                <>
                  <Square className="h-4 w-4 ml-2" />
                  إيقاف البوت
                </>
              )}
            </Button>
          </div>
        </div>
      </form>
    </Form>
  );
}
