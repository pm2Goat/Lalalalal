import React, { createContext, useContext, useEffect, useState, ReactNode } from 'react';
import { useToast } from '@/hooks/use-toast';
import { queryClient } from './queryClient';

interface WebSocketContextType {
  isConnected: boolean;
}

const WebSocketContext = createContext<WebSocketContextType>({
  isConnected: false,
});

export const useWebSocket = () => useContext(WebSocketContext);

interface WebSocketProviderProps {
  children: ReactNode;
}

export function WebSocketProvider({ children }: WebSocketProviderProps) {
  const [isConnected, setIsConnected] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    const wsUrl = `${protocol}//${window.location.host}`;
    
    const ws = new WebSocket(wsUrl);

    ws.onopen = () => {
      setIsConnected(true);
      console.log('WebSocket متصل');
    };

    ws.onclose = () => {
      setIsConnected(false);
      console.log('WebSocket منقطع');
    };

    ws.onmessage = (event) => {
      try {
        const data = JSON.parse(event.data);
        
        switch (data.type) {
          case 'bot_started':
            toast({
              title: "✅ تم تشغيل البوت",
              description: "البوت متصل ويعمل بشكل طبيعي",
            });
            queryClient.invalidateQueries({ queryKey: ['/api/bot/status'] });
            queryClient.invalidateQueries({ queryKey: ['/api/bot/stats'] });
            break;
            
          case 'bot_stopped':
            toast({
              title: "⛔ تم إيقاف البوت",
              description: "البوت غير متصل الآن",
            });
            queryClient.invalidateQueries({ queryKey: ['/api/bot/status'] });
            break;
            
          case 'message_sent':
            queryClient.invalidateQueries({ queryKey: ['/api/bot/stats'] });
            queryClient.invalidateQueries({ queryKey: ['/api/logs'] });
            break;
            
          case 'stats_update':
            queryClient.setQueryData(['/api/bot/stats'], data.data);
            break;
            
          case 'message_updated':
            toast({
              title: "✏️ تم تحديث الرسالة",
              description: "تم تحديث محتوى الرسالة بنجاح",
            });
            queryClient.invalidateQueries({ queryKey: ['/api/logs'] });
            break;
            
          default:
            console.log('رسالة WebSocket غير معروفة:', data);
        }
      } catch (error) {
        console.error('خطأ في معالجة رسالة WebSocket:', error);
      }
    };

    ws.onerror = (error) => {
      console.error('خطأ WebSocket:', error);
    };

    return () => {
      ws.close();
    };
  }, [toast]);

  const contextValue: WebSocketContextType = { isConnected };
  
  return React.createElement(
    WebSocketContext.Provider,
    { value: contextValue },
    children
  );
}
