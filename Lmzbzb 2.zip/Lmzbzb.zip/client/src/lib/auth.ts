import { apiRequest } from "./queryClient";

export interface LoginRequest {
  password: string;
}

export interface AuthResponse {
  message: string;
}

export const authApi = {
  login: async (credentials: LoginRequest): Promise<AuthResponse> => {
    const response = await apiRequest('POST', '/api/auth/login', credentials);
    return response.json();
  },

  logout: async (): Promise<AuthResponse> => {
    const response = await apiRequest('POST', '/api/auth/logout');
    return response.json();
  },

  getStatus: async (): Promise<{ authenticated: boolean }> => {
    const response = await apiRequest('GET', '/api/auth/status');
    return response.json();
  },
};
