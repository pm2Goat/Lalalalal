
const { Client } = require("discord.js-selfbot-v13");
let client = null;
let spamInterval = null;
let config = {
    channelId: "",
    message: "",
    delay: 1000
};

function startBot(token) {
    if (client) return;
    client = new Client();

    client.on("ready", () => {
        console.log(`[✅] Logged in as ${client.user.tag}`);
        spamInterval = setInterval(() => {
            if (config.channelId && config.message) {
                const channel = client.channels.cache.get(config.channelId);
                if (channel) channel.send(config.message).catch(() => {});
            }
        }, config.delay);
    });

    client.login(token).catch(console.error);
}

function stopSpam() {
    if (spamInterval) {
        clearInterval(spamInterval);
        spamInterval = null;
        console.log("[🛑] Spam stopped");
    }
}

function updateConfig(newConfig) {
    config = { ...config, ...newConfig };
}

module.exports = { startBot, stopSpam, updateConfig };
