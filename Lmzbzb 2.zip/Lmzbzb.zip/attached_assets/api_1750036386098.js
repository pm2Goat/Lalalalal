
const express = require("express");
const bodyParser = require("body-parser");
const path = require("path");
const { startBot, stopSpam, updateConfig } = require("./bot");

const app = express();
const PORT = 3000;

app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, "public")));

let token = "";

app.post("/start", (req, res) => {
    token = req.body.token;
    updateConfig({
        channelId: req.body.channelId,
        message: req.body.message,
        delay: parseInt(req.body.delay || "1000")
    });
    startBot(token);
    res.redirect("/");
});

app.post("/stop", (req, res) => {
    stopSpam();
    res.redirect("/");
});

app.post("/update", (req, res) => {
    updateConfig({ message: req.body.message });
    res.redirect("/");
});

app.listen(PORT, () => {
    console.log(`[🌐] Control Panel: http://localhost:${PORT}`);
});
