import express from 'express';
import { createServer } from 'http';
import { WebSocketServer } from 'ws';
import bcrypt from 'bcrypt';
import session from 'express-session';
import MemoryStore from 'memorystore';
import cors from 'cors';
import path from 'path';
import { fileURLToPath } from 'url';
import { Client, GatewayIntentBits } from 'discord.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const server = createServer(app);
const wss = new WebSocketServer({ server });

// إعدادات الجلسة
const SessionStore = MemoryStore(session);
app.use(session({
  secret: process.env.SESSION_SECRET || 'discord-bot-panel-secret-key',
  resave: false,
  saveUninitialized: false,
  store: new SessionStore({
    checkPeriod: 86400000 // 24 hours
  }),
  cookie: {
    secure: false,
    httpOnly: true,
    maxAge: 24 * 60 * 60 * 1000 // 24 hours
  }
}));

app.use(cors());
app.use(express.json());
app.use(express.static('public'));

// بيانات البوت المحفوظة في الذاكرة
let botData = {
  config: null,
  stats: {
    messagesSent: 0,
    uptime: 0,
    lastMessage: null,
    startTime: null
  },
  client: null,
  messageInterval: null,
  wsClients: new Set()
};

const DEFAULT_PASSWORD = 'admin123';

// WebSocket connections
wss.on('connection', (ws) => {
  botData.wsClients.add(ws);
  console.log('[📡] عميل WebSocket جديد متصل');
  
  ws.on('close', () => {
    botData.wsClients.delete(ws);
    console.log('[📡] انقطع اتصال عميل WebSocket');
  });
});

// إرسال رسائل WebSocket
function broadcast(data) {
  const message = JSON.stringify(data);
  botData.wsClients.forEach(ws => {
    if (ws.readyState === ws.OPEN) {
      ws.send(message);
    }
  });
}

// تسجيل الدخول
app.post('/api/auth/login', async (req, res) => {
  try {
    const { password } = req.body;
    
    if (!password) {
      return res.status(400).json({ message: 'كلمة المرور مطلوبة' });
    }

    // مقارنة كلمة المرور
    if (password === DEFAULT_PASSWORD) {
      req.session.authenticated = true;
      res.json({ message: 'تم تسجيل الدخول بنجاح' });
    } else {
      res.status(401).json({ message: 'كلمة مرور خاطئة' });
    }
  } catch (error) {
    console.error('خطأ في تسجيل الدخول:', error);
    res.status(500).json({ message: 'خطأ داخلي في الخادم' });
  }
});

// تسجيل الخروج
app.post('/api/auth/logout', (req, res) => {
  req.session.destroy((err) => {
    if (err) {
      return res.status(500).json({ message: 'فشل في تسجيل الخروج' });
    }
    res.json({ message: 'تم تسجيل الخروج بنجاح' });
  });
});

// حالة تسجيل الدخول
app.get('/api/auth/status', (req, res) => {
  res.json({ authenticated: !!req.session?.authenticated });
});

// Middleware للتحقق من تسجيل الدخول
const requireAuth = (req, res, next) => {
  if (!req.session?.authenticated) {
    return res.status(401).json({ message: 'غير مخول للوصول' });
  }
  next();
};

// تشغيل البوت
app.post('/api/bot/start', requireAuth, async (req, res) => {
  try {
    const { botToken, channelId, messageContent, messageDelay } = req.body;
    
    if (!botToken || !channelId || !messageContent) {
      return res.status(400).json({ message: 'جميع الحقول مطلوبة' });
    }

    // إيقاف البوت الحالي إذا كان يعمل
    if (botData.client) {
      await stopBot();
    }

    // إنشاء عميل جديد
    botData.client = new Client({
      intents: [GatewayIntentBits.Guilds, GatewayIntentBits.GuildMessages]
    });

    botData.config = {
      botToken,
      channelId,
      messageContent,
      messageDelay: messageDelay || 5
    };

    // تسجيل الدخول
    await botData.client.login(botToken);

    botData.client.once('ready', () => {
      console.log(`[✅] البوت ${botData.client.user.tag} جاهز للعمل`);
      
      // بدء إرسال الرسائل
      startMessageLoop();
      
      // تحديث الإحصائيات
      botData.stats.startTime = new Date();
      updateUptime();
      
      broadcast({
        type: 'bot_started',
        data: { status: 'متصل', botTag: botData.client.user.tag }
      });
    });

    botData.client.on('error', (error) => {
      console.error('[❌] خطأ في البوت:', error);
      broadcast({
        type: 'bot_error',
        data: { error: error.message }
      });
    });

    res.json({ message: 'تم تشغيل البوت بنجاح' });

  } catch (error) {
    console.error('خطأ في تشغيل البوت:', error);
    res.status(500).json({ message: 'فشل في تشغيل البوت: ' + error.message });
  }
});

// إيقاف البوت
app.post('/api/bot/stop', requireAuth, async (req, res) => {
  try {
    await stopBot();
    res.json({ message: 'تم إيقاف البوت بنجاح' });
  } catch (error) {
    console.error('خطأ في إيقاف البوت:', error);
    res.status(500).json({ message: 'فشل في إيقاف البوت' });
  }
});

// حالة البوت
app.get('/api/bot/status', requireAuth, (req, res) => {
  const isRunning = botData.client && botData.client.readyTimestamp;
  res.json({
    isRunning,
    status: isRunning ? 'متصل' : 'غير متصل',
    botTag: botData.client?.user?.tag || null
  });
});

// إحصائيات البوت
app.get('/api/bot/stats', requireAuth, (req, res) => {
  res.json(botData.stats);
});

// تحديث سريع للرسالة
app.post('/api/bot/quick-message', requireAuth, (req, res) => {
  try {
    const { message } = req.body;
    
    if (!message || !botData.config) {
      return res.status(400).json({ message: 'الرسالة مطلوبة والبوت يجب أن يكون يعمل' });
    }

    botData.config.messageContent = message;
    res.json({ message: 'تم تحديث الرسالة بنجاح' });
  } catch (error) {
    res.status(500).json({ message: 'فشل في تحديث الرسالة' });
  }
});

// دوال مساعدة
async function stopBot() {
  if (botData.messageInterval) {
    clearInterval(botData.messageInterval);
    botData.messageInterval = null;
  }
  
  if (botData.client) {
    await botData.client.destroy();
    botData.client = null;
  }
  
  botData.stats.startTime = null;
  
  broadcast({
    type: 'bot_stopped',
    data: { status: 'غير متصل' }
  });
}

function startMessageLoop() {
  if (botData.messageInterval) {
    clearInterval(botData.messageInterval);
  }
  
  botData.messageInterval = setInterval(async () => {
    try {
      if (!botData.client || !botData.config) return;
      
      const channel = await botData.client.channels.fetch(botData.config.channelId);
      if (channel && channel.isTextBased()) {
        await channel.send(botData.config.messageContent);
        
        // تحديث الإحصائيات
        botData.stats.messagesSent++;
        botData.stats.lastMessage = botData.config.messageContent;
        
        broadcast({
          type: 'message_sent',
          data: {
            message: botData.config.messageContent,
            stats: botData.stats
          }
        });
        
        console.log(`[📤] تم إرسال الرسالة: ${botData.config.messageContent}`);
      }
    } catch (error) {
      console.error('[❌] خطأ في إرسال الرسالة:', error);
    }
  }, (botData.config?.messageDelay || 5) * 1000);
}

function updateUptime() {
  setInterval(() => {
    if (botData.stats.startTime) {
      botData.stats.uptime = Math.floor((Date.now() - botData.stats.startTime) / 1000);
      
      broadcast({
        type: 'stats_update',
        data: botData.stats
      });
    }
  }, 1000);
}

// صفحات ثابتة
app.get('*', (req, res) => {
  if (!req.url.startsWith('/api')) {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
  }
});

const PORT = process.env.PORT || 5000;
server.listen(PORT, '0.0.0.0', () => {
  console.log(`[🌐] لوحة تحكم البوت تعمل على المنفذ: ${PORT}`);
  console.log(`[🔐] كلمة المرور الافتراضية: ${DEFAULT_PASSWORD}`);
  
  // بدء تحديث وقت التشغيل
  updateUptime();
});

// التعامل مع إيقاف التطبيق
process.on('SIGINT', async () => {
  console.log('[⚠️] جاري إيقاف التطبيق...');
  await stopBot();
  process.exit(0);
});

process.on('SIGTERM', async () => {
  console.log('[⚠️] جاري إيقاف التطبيق...');
  await stopBot();
  process.exit(0);
});