import { Client, GatewayIntentBits, TextChannel } from 'discord.js';
import { storage } from '../storage';
import { WebSocket } from 'ws';

export class DiscordBotService {
  private client: Client | null = null;
  private messageInterval: NodeJS.Timeout | null = null;
  private startTime: Date | null = null;
  private wsClients: Set<WebSocket> = new Set();

  constructor() {
    this.setupHeartbeat();
  }

  addWSClient(ws: WebSocket) {
    this.wsClients.add(ws);
    ws.on('close', () => {
      this.wsClients.delete(ws);
    });
  }

  private broadcast(data: any) {
    const message = JSON.stringify(data);
    this.wsClients.forEach(ws => {
      if (ws.readyState === WebSocket.OPEN) {
        ws.send(message);
      }
    });
  }

  private setupHeartbeat() {
    setInterval(async () => {
      if (this.client && this.startTime) {
        const uptime = Math.floor((Date.now() - this.startTime.getTime()) / 1000);
        await storage.updateUptime(uptime);
        
        const stats = await storage.getBotStats();
        this.broadcast({
          type: 'stats_update',
          data: stats
        });
      }
    }, 1000);
  }

  async startBot(token: string, channelId: string, message: string, delay: number): Promise<void> {
    if (this.client) {
      throw new Error('البوت يعمل بالفعل');
    }

    try {
      this.client = new Client({
        intents: [
          GatewayIntentBits.Guilds,
          GatewayIntentBits.GuildMessages,
          GatewayIntentBits.MessageContent,
        ],
      });

      await new Promise<void>((resolve, reject) => {
        this.client!.once('ready', () => {
          console.log(`تم تسجيل الدخول كـ ${this.client!.user?.tag}`);
          resolve();
        });

        this.client!.once('error', (error) => {
          reject(error);
        });

        this.client!.login(token).catch(reject);
      });

      this.startTime = new Date();
      await storage.createOrUpdateBotStats({
        messagesSent: 0,
        uptime: 0,
        startedAt: this.startTime,
      });

      await storage.updateBotStatus(true);
      await storage.addActivityLog({
        type: 'success',
        message: 'تم تشغيل البوت بنجاح',
      });

      this.startMessageLoop(channelId, message, delay);
      
      this.broadcast({
        type: 'bot_started',
        data: { status: 'متصل' }
      });

    } catch (error) {
      this.client = null;
      await storage.addActivityLog({
        type: 'error',
        message: `فشل في تشغيل البوت: ${error instanceof Error ? error.message : 'خطأ غير معروف'}`,
      });
      throw error;
    }
  }

  private startMessageLoop(channelId: string, message: string, delay: number) {
    if (this.messageInterval) {
      clearInterval(this.messageInterval);
    }

    this.messageInterval = setInterval(async () => {
      try {
        const channel = this.client?.channels.cache.get(channelId) as TextChannel;
        if (channel && channel.isTextBased()) {
          await channel.send(message);
          await storage.incrementMessageCount();
          await storage.createOrUpdateBotStats({
            lastMessage: message,
            lastMessageAt: new Date(),
          });

          const stats = await storage.getBotStats();
          this.broadcast({
            type: 'message_sent',
            data: { stats, message }
          });

          await storage.addActivityLog({
            type: 'info',
            message: `تم إرسال رسالة إلى القناة`,
          });
        }
      } catch (error) {
        await storage.addActivityLog({
          type: 'error',
          message: `فشل في إرسال الرسالة: ${error instanceof Error ? error.message : 'خطأ غير معروف'}`,
        });
      }
    }, delay * 1000);
  }

  async stopBot(): Promise<void> {
    if (this.messageInterval) {
      clearInterval(this.messageInterval);
      this.messageInterval = null;
    }

    if (this.client) {
      await this.client.destroy();
      this.client = null;
    }

    this.startTime = null;
    await storage.updateBotStatus(false);
    await storage.addActivityLog({
      type: 'warning',
      message: 'تم إيقاف البوت',
    });

    this.broadcast({
      type: 'bot_stopped',
      data: { status: 'غير متصل' }
    });
  }

  async updateMessage(newMessage: string): Promise<void> {
    const config = await storage.getBotConfig();
    if (config) {
      await storage.createOrUpdateBotConfig({
        ...config,
        messageContent: newMessage,
      });

      await storage.addActivityLog({
        type: 'info',
        message: 'تم تحديث محتوى الرسالة',
      });

      this.broadcast({
        type: 'message_updated',
        data: { message: newMessage }
      });
    }
  }

  isRunning(): boolean {
    return this.client !== null && this.client.isReady();
  }

  getStatus(): string {
    return this.isRunning() ? 'متصل' : 'غير متصل';
  }
}

export const discordBot = new DiscordBotService();
