import express from "express";
import session from "express-session";
import cors from "cors";
import { createServer } from "http";
import { WebSocketServer } from "ws";
import bcrypt from "bcrypt";
import { storage } from "./storage.js";
import { discordBot } from "./services/discord-bot.js";
import { 
  loginSchema, 
  insertBotConfigSchema, 
  quickMessageSchema 
} from "../shared/schema.js";

// Extend Express Request interface
declare module 'express-serve-static-core' {
  interface Request {
    session: {
      authenticated?: boolean;
      destroy(callback: (err?: any) => void): void;
    } & Express.Session;
  }
}

const app = express();
const server = createServer(app);

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Session configuration
app.use(session({
  secret: process.env.SESSION_SECRET || "discord-bot-panel-secret-key",
  resave: false,
  saveUninitialized: false,
  cookie: {
    secure: false,
    httpOnly: true,
    maxAge: 24 * 60 * 60 * 1000 // 24 hours
  }
}));

// WebSocket setup
const wss = new WebSocketServer({ server });
wss.on('connection', (ws) => {
  discordBot.addWSClient(ws);
});

// Authentication middleware
const requireAuth = (req: express.Request, res: express.Response, next: express.NextFunction) => {
  if (!req.session?.authenticated) {
    return res.status(401).json({ message: "غير مسموح بالوصول" });
  }
  next();
};

const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || "admin123";
const ADMIN_PASSWORD_HASH = bcrypt.hashSync(ADMIN_PASSWORD, 10);

// Routes
app.post('/api/auth/login', async (req, res) => {
  try {
    const { password } = loginSchema.parse(req.body);
    
    const isValid = bcrypt.compareSync(password, ADMIN_PASSWORD_HASH);
    if (!isValid) {
      return res.status(401).json({ message: "كلمة المرور غير صحيحة" });
    }

    req.session.authenticated = true;
    await storage.addActivityLog({
      type: 'info',
      message: 'تم تسجيل دخول المشرف',
    });

    res.json({ message: "تم تسجيل الدخول بنجاح" });
  } catch (error) {
    res.status(400).json({ message: "بيانات غير صحيحة" });
  }
});

app.post('/api/auth/logout', (req, res) => {
  req.session.destroy(() => {
    res.json({ message: "تم تسجيل الخروج بنجاح" });
  });
});

app.get('/api/auth/status', (req, res) => {
  res.json({ authenticated: !!req.session?.authenticated });
});

app.get('/api/bot/config', requireAuth, async (req, res) => {
  try {
    const config = await storage.getBotConfig();
    res.json(config || null);
  } catch (error) {
    res.status(500).json({ message: "فشل في جلب الإعدادات" });
  }
});

app.post('/api/bot/start', requireAuth, async (req, res) => {
  try {
    const config = insertBotConfigSchema.parse(req.body);
    
    if (discordBot.isRunning()) {
      return res.status(400).json({ message: "البوت يعمل بالفعل" });
    }

    await storage.createOrUpdateBotConfig(config);
    await discordBot.startBot(
      config.botToken,
      config.channelId,
      config.messageContent,
      config.messageDelay
    );

    res.json({ message: "تم تشغيل البوت بنجاح" });
  } catch (error) {
    res.status(400).json({ 
      message: error instanceof Error ? error.message : "فشل في تشغيل البوت" 
    });
  }
});

app.post('/api/bot/stop', requireAuth, async (req, res) => {
  try {
    await discordBot.stopBot();
    res.json({ message: "تم إيقاف البوت بنجاح" });
  } catch (error) {
    res.status(500).json({ message: "فشل في إيقاف البوت" });
  }
});

app.get('/api/bot/status', requireAuth, async (req, res) => {
  try {
    const isRunning = discordBot.isRunning();
    const status = discordBot.getStatus();
    res.json({ isRunning, status });
  } catch (error) {
    res.status(500).json({ message: "فشل في جلب حالة البوت" });
  }
});

app.get('/api/bot/stats', requireAuth, async (req, res) => {
  try {
    const stats = await storage.getBotStats();
    res.json(stats);
  } catch (error) {
    res.status(500).json({ message: "فشل في جلب الإحصائيات" });
  }
});

app.post('/api/bot/quick-message', requireAuth, async (req, res) => {
  try {
    const { message } = quickMessageSchema.parse(req.body);
    await discordBot.updateMessage(message);
    res.json({ message: "تم تحديث الرسالة بنجاح" });
  } catch (error) {
    res.status(400).json({ 
      message: error instanceof Error ? error.message : "فشل في تحديث الرسالة" 
    });
  }
});

app.get('/api/logs', requireAuth, async (req, res) => {
  try {
    const limit = parseInt((req.query.limit as string) || '50');
    const logs = await storage.getActivityLogs(limit);
    res.json(logs);
  } catch (error) {
    res.status(500).json({ message: "فشل في جلب السجلات" });
  }
});

app.delete('/api/logs', requireAuth, async (req, res) => {
  try {
    await storage.clearActivityLogs();
    res.json({ message: "تم مسح السجلات بنجاح" });
  } catch (error) {
    res.status(500).json({ message: "فشل في مسح السجلات" });
  }
});

// Serve static files in production
if (process.env.NODE_ENV === 'production') {
  app.use(express.static('dist'));
  app.get('*', (req, res) => {
    res.sendFile('dist/index.html', { root: process.cwd() });
  });
}

export { app, server };