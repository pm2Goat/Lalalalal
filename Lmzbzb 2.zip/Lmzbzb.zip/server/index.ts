import express from "express";
import session from "express-session";
import cors from "cors";
import { createServer } from "http";
import { WebSocketServer } from "ws";
import bcrypt from "bcrypt";
import { storage } from "./storage.js";
import { discordBot } from "./services/discord-bot.js";
import { 
  loginSchema, 
  insertBotConfigSchema, 
  quickMessageSchema 
} from "../shared/schema.js";

const app = express();
const server = createServer(app);

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Session configuration
app.use(session({
  secret: process.env.SESSION_SECRET || "discord-bot-panel-secret-key",
  resave: false,
  saveUninitialized: false,
  cookie: {
    secure: false,
    httpOnly: true,
    maxAge: 24 * 60 * 60 * 1000
  }
} as any));

// WebSocket setup
const wss = new WebSocketServer({ server });
wss.on('connection', (ws) => {
  discordBot.addWSClient(ws);
});

// Authentication middleware
const requireAuth = (req: any, res: any, next: any) => {
  if (!req.session?.authenticated) {
    return res.status(401).json({ message: "غير مسموح بالوصول" });
  }
  next();
};

const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || "admin123";
const ADMIN_PASSWORD_HASH = bcrypt.hashSync(ADMIN_PASSWORD, 10);

// Routes
app.post('/api/auth/login', async (req: any, res: any) => {
  try {
    const { password } = loginSchema.parse(req.body);
    
    const isValid = bcrypt.compareSync(password, ADMIN_PASSWORD_HASH);
    if (!isValid) {
      return res.status(401).json({ message: "كلمة المرور غير صحيحة" });
    }

    req.session.authenticated = true;
    await storage.addActivityLog({
      type: 'info',
      message: 'تم تسجيل دخول المشرف',
    });

    res.json({ message: "تم تسجيل الدخول بنجاح" });
  } catch (error) {
    res.status(400).json({ message: "بيانات غير صحيحة" });
  }
});

app.post('/api/auth/logout', (req: any, res: any) => {
  if (req.session) {
    req.session.destroy(() => {
      res.json({ message: "تم تسجيل الخروج بنجاح" });
    });
  } else {
    res.json({ message: "تم تسجيل الخروج بنجاح" });
  }
});

app.get('/api/auth/status', (req: any, res: any) => {
  res.json({ authenticated: !!req.session?.authenticated });
});

app.get('/api/bot/config', requireAuth, async (req: any, res: any) => {
  try {
    const config = await storage.getBotConfig();
    res.json(config || null);
  } catch (error) {
    res.status(500).json({ message: "فشل في جلب الإعدادات" });
  }
});

app.post('/api/bot/start', requireAuth, async (req: any, res: any) => {
  try {
    const config = insertBotConfigSchema.parse(req.body);
    
    if (discordBot.isRunning()) {
      return res.status(400).json({ message: "البوت يعمل بالفعل" });
    }

    await storage.createOrUpdateBotConfig(config);
    await discordBot.startBot(
      config.botToken,
      config.channelId,
      config.messageContent,
      config.messageDelay || 5
    );

    res.json({ message: "تم تشغيل البوت بنجاح" });
  } catch (error: any) {
    res.status(400).json({ 
      message: error.message || "فشل في تشغيل البوت" 
    });
  }
});

app.post('/api/bot/stop', requireAuth, async (req: any, res: any) => {
  try {
    await discordBot.stopBot();
    res.json({ message: "تم إيقاف البوت بنجاح" });
  } catch (error) {
    res.status(500).json({ message: "فشل في إيقاف البوت" });
  }
});

app.get('/api/bot/status', requireAuth, async (req: any, res: any) => {
  try {
    const isRunning = discordBot.isRunning();
    const status = discordBot.getStatus();
    res.json({ isRunning, status });
  } catch (error) {
    res.status(500).json({ message: "فشل في جلب حالة البوت" });
  }
});

app.get('/api/bot/stats', requireAuth, async (req: any, res: any) => {
  try {
    const stats = await storage.getBotStats();
    res.json(stats);
  } catch (error) {
    res.status(500).json({ message: "فشل في جلب الإحصائيات" });
  }
});

app.post('/api/bot/quick-message', requireAuth, async (req: any, res: any) => {
  try {
    const { message } = quickMessageSchema.parse(req.body);
    await discordBot.updateMessage(message);
    res.json({ message: "تم تحديث الرسالة بنجاح" });
  } catch (error: any) {
    res.status(400).json({ 
      message: error.message || "فشل في تحديث الرسالة" 
    });
  }
});

app.get('/api/logs', requireAuth, async (req: any, res: any) => {
  try {
    const limit = parseInt((req.query.limit as string) || '50');
    const logs = await storage.getActivityLogs(limit);
    res.json(logs);
  } catch (error) {
    res.status(500).json({ message: "فشل في جلب السجلات" });
  }
});

app.delete('/api/logs', requireAuth, async (req: any, res: any) => {
  try {
    await storage.clearActivityLogs();
    res.json({ message: "تم مسح السجلات بنجاح" });
  } catch (error) {
    res.status(500).json({ message: "فشل في مسح السجلات" });
  }
});

// Serve static files
app.use(express.static('dist/public'));
app.get('*', (req: any, res: any) => {
  if (!req.url.startsWith('/api')) {
    res.sendFile('dist/public/index.html', { root: process.cwd() });
  }
});

const PORT = 5000;
server.listen(PORT, '0.0.0.0', () => {
  console.log(`[🌐] لوحة تحكم البوت تعمل على: http://localhost:${PORT}`);
  console.log(`[🔐] كلمة المرور الافتراضية: ${ADMIN_PASSWORD}`);
});
