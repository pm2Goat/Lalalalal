import type { Express, Request, Response, NextFunction } from "express";
import { createServer, type Server } from "http";
import { WebSocketServer } from "ws";
import bcrypt from "bcrypt";
import { storage } from "./storage";
import { discordBot } from "./services/discord-bot";
import { 
  loginSchema, 
  insertBotConfigSchema, 
  quickMessageSchema 
} from "@shared/schema";

// Extend Express Request interface to include session
declare module 'express' {
  interface Request {
    session?: {
      authenticated?: boolean;
      destroy(callback: (err?: any) => void): void;
    };
  }
}

const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || "admin123";
const ADMIN_PASSWORD_HASH = bcrypt.hashSync(ADMIN_PASSWORD, 10);

export async function registerRoutes(app: Express): Promise<Server> {
  const httpServer = createServer(app);
  
  // Setup WebSocket server
  const wss = new WebSocketServer({ server: httpServer });
  wss.on('connection', (ws) => {
    discordBot.addWSClient(ws);
  });

  // Authentication middleware
  const requireAuth = (req: Request, res: Response, next: NextFunction) => {
    if (!req.session?.authenticated) {
      return res.status(401).json({ message: "غير مسموح بالوصول" });
    }
    next();
  };

  // Login endpoint
  app.post('/api/auth/login', async (req: Request, res: Response) => {
    try {
      const { password } = loginSchema.parse(req.body);
      
      const isValid = bcrypt.compareSync(password, ADMIN_PASSWORD_HASH);
      if (!isValid) {
        return res.status(401).json({ message: "كلمة المرور غير صحيحة" });
      }

      if (req.session) {
        req.session.authenticated = true;
      }
      await storage.addActivityLog({
        type: 'info',
        message: 'تم تسجيل دخول المشرف',
      });

      res.json({ message: "تم تسجيل الدخول بنجاح" });
    } catch (error) {
      res.status(400).json({ message: "بيانات غير صحيحة" });
    }
  });

  // Logout endpoint
  app.post('/api/auth/logout', (req: Request, res: Response) => {
    if (req.session) {
      req.session.destroy(() => {
        res.json({ message: "تم تسجيل الخروج بنجاح" });
      });
    } else {
      res.json({ message: "تم تسجيل الخروج بنجاح" });
    }
  });

  // Check authentication status
  app.get('/api/auth/status', (req: Request, res: Response) => {
    res.json({ authenticated: !!req.session?.authenticated });
  });

  // Get bot configuration
  app.get('/api/bot/config', requireAuth, async (req, res) => {
    try {
      const config = await storage.getBotConfig();
      res.json(config || null);
    } catch (error) {
      res.status(500).json({ message: "فشل في جلب الإعدادات" });
    }
  });

  // Start bot
  app.post('/api/bot/start', requireAuth, async (req, res) => {
    try {
      const config = insertBotConfigSchema.parse(req.body);
      
      if (discordBot.isRunning()) {
        return res.status(400).json({ message: "البوت يعمل بالفعل" });
      }

      await storage.createOrUpdateBotConfig(config);
      await discordBot.startBot(
        config.botToken,
        config.channelId,
        config.messageContent,
        config.messageDelay || 5
      );

      res.json({ message: "تم تشغيل البوت بنجاح" });
    } catch (error) {
      res.status(400).json({ 
        message: error instanceof Error ? error.message : "فشل في تشغيل البوت" 
      });
    }
  });

  // Stop bot
  app.post('/api/bot/stop', requireAuth, async (req, res) => {
    try {
      await discordBot.stopBot();
      res.json({ message: "تم إيقاف البوت بنجاح" });
    } catch (error) {
      res.status(500).json({ message: "فشل في إيقاف البوت" });
    }
  });

  // Get bot status
  app.get('/api/bot/status', requireAuth, async (req, res) => {
    try {
      const isRunning = discordBot.isRunning();
      const status = discordBot.getStatus();
      res.json({ isRunning, status });
    } catch (error) {
      res.status(500).json({ message: "فشل في جلب حالة البوت" });
    }
  });

  // Get bot statistics
  app.get('/api/bot/stats', requireAuth, async (req, res) => {
    try {
      const stats = await storage.getBotStats();
      res.json(stats);
    } catch (error) {
      res.status(500).json({ message: "فشل في جلب الإحصائيات" });
    }
  });

  // Update message quickly
  app.post('/api/bot/quick-message', requireAuth, async (req, res) => {
    try {
      const { message } = quickMessageSchema.parse(req.body);
      await discordBot.updateMessage(message);
      res.json({ message: "تم تحديث الرسالة بنجاح" });
    } catch (error) {
      res.status(400).json({ 
        message: error instanceof Error ? error.message : "فشل في تحديث الرسالة" 
      });
    }
  });

  // Get activity logs
  app.get('/api/logs', requireAuth, async (req: Request, res: Response) => {
    try {
      const limit = parseInt((req.query.limit as string) || '50');
      const logs = await storage.getActivityLogs(limit);
      res.json(logs);
    } catch (error) {
      res.status(500).json({ message: "فشل في جلب السجلات" });
    }
  });

  // Clear activity logs
  app.delete('/api/logs', requireAuth, async (req, res) => {
    try {
      await storage.clearActivityLogs();
      res.json({ message: "تم مسح السجلات بنجاح" });
    } catch (error) {
      res.status(500).json({ message: "فشل في مسح السجلات" });
    }
  });

  return httpServer;
}
