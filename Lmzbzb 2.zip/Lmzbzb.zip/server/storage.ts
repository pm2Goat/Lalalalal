import { 
  users, 
  botConfigs, 
  botStats, 
  activityLogs,
  type User, 
  type InsertUser, 
  type BotConfig, 
  type InsertBotConfig,
  type BotStats,
  type ActivityLog,
  type InsertActivityLog
} from "@shared/schema";

export interface IStorage {
  // User management
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  // Bot configuration
  getBotConfig(): Promise<BotConfig | undefined>;
  createOrUpdateBotConfig(config: InsertBotConfig): Promise<BotConfig>;
  updateBotStatus(isActive: boolean): Promise<void>;

  // Bot statistics
  getBotStats(): Promise<BotStats | undefined>;
  createOrUpdateBotStats(stats: Partial<BotStats>): Promise<BotStats>;
  incrementMessageCount(): Promise<void>;
  updateUptime(uptime: number): Promise<void>;

  // Activity logs
  getActivityLogs(limit?: number): Promise<ActivityLog[]>;
  addActivityLog(log: InsertActivityLog): Promise<ActivityLog>;
  clearActivityLogs(): Promise<void>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private botConfig: BotConfig | undefined;
  private botStats: BotStats | undefined;
  private activityLogs: Map<number, ActivityLog>;
  private currentUserId: number;
  private currentLogId: number;

  constructor() {
    this.users = new Map();
    this.activityLogs = new Map();
    this.currentUserId = 1;
    this.currentLogId = 1;
    this.initializeDefaultStats();
  }

  private initializeDefaultStats() {
    this.botStats = {
      id: 1,
      messagesSent: 0,
      uptime: 0,
      lastMessage: null,
      lastMessageAt: null,
      startedAt: null,
    };
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  async getBotConfig(): Promise<BotConfig | undefined> {
    return this.botConfig;
  }

  async createOrUpdateBotConfig(config: InsertBotConfig): Promise<BotConfig> {
    const newConfig: BotConfig = {
      id: this.botConfig?.id || 1,
      botToken: config.botToken,
      channelId: config.channelId,
      messageContent: config.messageContent,
      messageDelay: config.messageDelay || 5,
      isActive: config.isActive || false,
      createdAt: this.botConfig?.createdAt || new Date(),
    };
    this.botConfig = newConfig;
    return newConfig;
  }

  async updateBotStatus(isActive: boolean): Promise<void> {
    if (this.botConfig) {
      this.botConfig.isActive = isActive;
    }
  }

  async getBotStats(): Promise<BotStats | undefined> {
    return this.botStats;
  }

  async createOrUpdateBotStats(stats: Partial<BotStats>): Promise<BotStats> {
    this.botStats = {
      id: 1,
      messagesSent: 0,
      uptime: 0,
      lastMessage: null,
      lastMessageAt: null,
      startedAt: null,
      ...this.botStats,
      ...stats,
    };
    return this.botStats;
  }

  async incrementMessageCount(): Promise<void> {
    if (this.botStats) {
      this.botStats.messagesSent++;
    }
  }

  async updateUptime(uptime: number): Promise<void> {
    if (this.botStats) {
      this.botStats.uptime = uptime;
    }
  }

  async getActivityLogs(limit: number = 50): Promise<ActivityLog[]> {
    const logs = Array.from(this.activityLogs.values())
      .sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime())
      .slice(0, limit);
    return logs;
  }

  async addActivityLog(log: InsertActivityLog): Promise<ActivityLog> {
    const id = this.currentLogId++;
    const newLog: ActivityLog = {
      id,
      ...log,
      timestamp: new Date(),
    };
    this.activityLogs.set(id, newLog);
    return newLog;
  }

  async clearActivityLogs(): Promise<void> {
    this.activityLogs.clear();
    this.currentLogId = 1;
  }
}

export const storage = new MemStorage();
