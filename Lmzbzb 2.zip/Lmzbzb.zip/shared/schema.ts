import { pgTable, text, serial, integer, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const botConfigs = pgTable("bot_configs", {
  id: serial("id").primaryKey(),
  botToken: text("bot_token").notNull(),
  channelId: text("channel_id").notNull(),
  messageContent: text("message_content").notNull(),
  messageDelay: integer("message_delay").notNull().default(5),
  isActive: boolean("is_active").notNull().default(false),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const botStats = pgTable("bot_stats", {
  id: serial("id").primaryKey(),
  messagesSent: integer("messages_sent").notNull().default(0),
  uptime: integer("uptime").notNull().default(0),
  lastMessage: text("last_message"),
  lastMessageAt: timestamp("last_message_at"),
  startedAt: timestamp("started_at"),
});

export const activityLogs = pgTable("activity_logs", {
  id: serial("id").primaryKey(),
  type: text("type").notNull(), // success, warning, error, info
  message: text("message").notNull(),
  timestamp: timestamp("timestamp").notNull().defaultNow(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export const insertBotConfigSchema = createInsertSchema(botConfigs).omit({
  id: true,
  createdAt: true,
}).extend({
  messageDelay: z.number().min(1).default(5),
  isActive: z.boolean().default(false),
});

export const insertActivityLogSchema = createInsertSchema(activityLogs).omit({
  id: true,
  timestamp: true,
});

export const loginSchema = z.object({
  password: z.string().min(1, "كلمة المرور مطلوبة"),
});

export const quickMessageSchema = z.object({
  message: z.string().min(1, "الرسالة مطلوبة").max(2000, "الرسالة طويلة جداً"),
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type BotConfig = typeof botConfigs.$inferSelect;
export type InsertBotConfig = z.infer<typeof insertBotConfigSchema>;
export type BotStats = typeof botStats.$inferSelect;
export type ActivityLog = typeof activityLogs.$inferSelect;
export type InsertActivityLog = z.infer<typeof insertActivityLogSchema>;
export type LoginRequest = z.infer<typeof loginSchema>;
export type QuickMessageRequest = z.infer<typeof quickMessageSchema>;
